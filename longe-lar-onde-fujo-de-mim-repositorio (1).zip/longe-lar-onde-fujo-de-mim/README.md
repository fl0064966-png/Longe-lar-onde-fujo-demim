# Longe lar onde fujo de mim

Site do livro *Longe lar onde fujo de mim*, de João Manoel Bentes, com a primeira parte aberta para leitura gratuita.

O site inteiro é um único arquivo: `index.html`. Para ver, basta abri-lo no navegador. A página de leitura fica em `index.html#leitura`.

## Como adicionar um novo capítulo

Na página de leitura, cada capítulo tem sua própria aba. A aba de um capítulo novo aparece sozinha.

1. Abra o `index.html` e procure por `PRÓXIMOS CAPÍTULOS`.
2. Cole o capítulo logo abaixo dessa nota, seguindo o modelo:

   ```html
   <section class="capitulo" id="capitulo-3">
     <h2>Capítulo Três ou Título</h2>
     <p>Primeiro parágrafo.</p>
     <p>Segundo parágrafo.</p>
   </section>
   ```

   O nome da aba vem do título: o trecho antes de " ou " vira o número, e o trecho depois vira o subtítulo. O `id` precisa ser diferente em cada capítulo.

3. Para os sussurros que interrompem o texto, use:

   ```html
   <span class="voz">(Eu te vejo)</span>
   ```

O fim de cada capítulo ganha automaticamente um botão para o próximo. O aviso "Os próximos capítulos chegam aqui em breve." só aparece na aba do último capítulo. Apague-o quando a publicação terminar.

## Link de compra

Quando o livro estiver à venda, preencha `LINK_COMPRA` no início do script do `index.html`. Os botões de compra passam a funcionar sozinhos.

## Direitos

© 2026 João Manoel Bentes. Todos os direitos reservados.
